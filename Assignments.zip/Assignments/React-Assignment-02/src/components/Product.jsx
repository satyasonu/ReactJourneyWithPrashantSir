import React from 'react'

const Product = ({products}) => {
  return (
    <tbody>
      {products.map(product => {
        return(
          <tr key={product.ID}>
            <td >{product.ID}</td>
            <td >{product.ProductName}</td>
            <td >{product.Quantity}</td>
            <td >Rs. {product.Price}</td>
          </tr>
        )
      })}
      </tbody>
  )
}

export default Product