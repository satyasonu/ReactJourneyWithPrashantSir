import React from 'react'
import Product from './Product'
const ProductList = ({products}) => {
  return (
    <>
      <thead>
        <tr>
          <th>ID</th>
          <th>Product Name</th>
          <th>Quantity</th>
          <th>Price</th>
        </tr>
      </thead>
      <Product products={products} />
    </>
  )
}

export default ProductList