import React from "react";
import ProductList from "./ProductList";

const AllProductPage = ({products}) => {
  
  return (
    <table>
      <ProductList products={products}></ProductList>
    </table>
  );
};

export default AllProductPage;
