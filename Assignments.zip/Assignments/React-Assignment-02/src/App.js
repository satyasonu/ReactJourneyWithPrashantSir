import "./App.css";
import AllProductPage from './components/AllProductPage'

function App() {
  const products = [
    {
      ID : 1,
      ProductName : "Moto G5",
      Quantity: 2,
      Price: "13000"
    },
    {
      ID : 2,
      ProductName : "Racold Geyser",
      Quantity: 3,
      Price: "6000"
    },
    {
      ID : 3,
      ProductName : "Dell Inspiron",
      Quantity: 4,
      Price: "50000"
    }
  ]
  return (
    <div className="App">
      <h1>Product List</h1>
      <AllProductPage products={products}/>
    </div>
  );
}

export default App;
