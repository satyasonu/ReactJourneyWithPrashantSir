import "./App.css";
import { useState } from "react";

function App() {
  const [counter, setCounter] = useState(0);
  return (
    <div className="App">
      <h1>Counter Demo</h1>
      <h3>Counter: {counter}</h3>
      <button onClick={(prev) => setCounter(counter - 1)}>
        Decrement Counter
      </button>

      <button onClick={(prev) => setCounter(counter + 1)}>
        Increment Counter
      </button>
    </div>
  );
}

export default App;
