import React from "react";
import { Formik, Field, Form, ErrorMessage } from "formik";
import * as Yup from "yup";
import '../App.css'
import { useNavigate } from "react-router-dom";


const AddProduct = ({products}) => {
  const url = 'http://localhost:4000/products';
  const navigate = useNavigate()
  const sendData = ( newData ) => {
    const checkData = products.filter((item) => item.ProductName === newData.ProductName)
    if(checkData.length === 0)
    {fetch(url, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body:JSON.stringify(newData)
    }).then(response => response.json())
    .then(data => console.log(data))} else{
      alert('Product Name already exists')
    }
  }
  
  return (
    <Formik
      initialValues={{ name: "", quantity: "", price: "" }}
      validationSchema={Yup.object({
        name: Yup.string().required("Product Name is required"),
        quantity: Yup.number().required("Quantity is required"),
        price: Yup.number().required("price is Required"),
      })}
      onSubmit={(values, { setSubmitting }) => {
          // alert(JSON.stringify(values, null, 2));
          setSubmitting(false);
          const newData = {id: products.length === 0 ? 1 : products[products.length -1].id + 1, ProductName: values.name, Quantity: values.quantity, Price: values.price }
          if(values !== ""){sendData(newData)} 
          navigate('/products')
      }}
    >
      
      <Form>
      <div><h1>Add Product</h1></div>
        <Field name="name" type="text" placeholder="Enter Product name" />
        <span className="error"><ErrorMessage name="name" /></span><br />

        <Field name="quantity" type="text" placeholder="Enter Quantity" />
        <span className="error"><ErrorMessage name="quantity"/></span><br />

        <Field name="price" type="price" placeholder="Enter Price" />
        <span className="error"><ErrorMessage name="price"/></span><br />

        <button type="submit">Submit</button>
      </Form>
    </Formik>
  );
};

export default AddProduct;
