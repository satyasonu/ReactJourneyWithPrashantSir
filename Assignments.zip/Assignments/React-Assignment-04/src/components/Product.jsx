import React, {useContext} from 'react'
import { DataProvider } from './AllProductPage'
import {  useNavigate } from 'react-router-dom'

const Product = () => {
  const {products} = useContext(DataProvider);
  const navigate = useNavigate();
  var askUser;
  const confirmation = (product) => {
     askUser = window.confirm("Are you sure you want to view the details?")
     if(askUser){
        navigate(`/products/${product.ProductName}`, {state:product})
     }
  }
  return (
    <tbody>
      {products.length !== 0 && products.map(product => {
        return(
          <tr key={product.id}>
            <td ><button style={{color: '#000', backgroundColor: 'transparent', border: 'none', textDecoration: 'underline', cursor: 'pointer'}} onClick={() => confirmation(product)}>{product.ProductName} </button ></td>
            <td >{product.Quantity}</td>
            <td >Rs. {product.Price}</td>
          </tr>
        )
      })}
      </tbody>
  )
}

export default Product