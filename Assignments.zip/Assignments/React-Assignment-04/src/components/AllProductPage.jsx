import React, { createContext } from "react";
import ProductList from "./ProductList";
import { Link } from "react-router-dom";

export const DataProvider = createContext();

const AllProductPage = ({products}) => {
  // console.log(products)
  
  return (
    <DataProvider.Provider value={{products}}>
    <h1>Product List</h1>
    <table>
      <ProductList></ProductList>
    </table>
    <Link to="/addproduct">Add Product</Link>
    </DataProvider.Provider>
  );
};

export default AllProductPage;
