import React from 'react'
import Product from './Product'
const ProductList = () => {
  return (
    <>
      <thead>
        <tr>
          <th>Product Name</th>
          <th>Quantity</th>
          <th>Price</th>
        </tr>
      </thead>
      <Product/>
    </>
  )
}

export default ProductList