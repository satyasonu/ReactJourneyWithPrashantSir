import React from 'react'
import { Link, useLocation, useNavigate } from 'react-router-dom'

const ProductView = () => {
  const {state} = useLocation();
  const navigate= useNavigate();return (
    <div>
      <h1>product Details</h1>
      <p><b>Product Name:</b> {state && state.ProductName}</p>
      <Link onClick={() => navigate(-1)}  >Back</Link>
    </div>
  )
}

export default ProductView