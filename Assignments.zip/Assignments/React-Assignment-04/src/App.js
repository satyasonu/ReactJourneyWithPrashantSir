import "./App.css";
import AllProductPage from "./components/AllProductPage";
import About from "./components/About";
import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import { useEffect, useState } from "react";
import AddProduct from "./components/AddProduct";
import ProductView from "./components/ProductView";

function App() {
  const [products, setProducts] = useState([]);
  const url = 'http://localhost:4000/products';

  const fetchData = () => {
    fetch(url)
      .then(res => {
        if(!res.ok){
          throw Error("Error while fetching Data")
        }
        return res.json();
      })
      .then(data => {
        setProducts(data)
      })
  }
  
  useEffect(() => {
    fetchData()
    
  }, [])

  return (
    
    <div className="App">
      <Router>
        <nav>
          <Link to="/" >About</Link>
          <Link to="/products" onClick={fetchData}>Products</Link>
        </nav>
        <Routes>
          <Route path="/" element={<About />}/>
          <Route
              path="/products"
              element={<AllProductPage products={products} />}
            />
            <Route path="/addproduct" element={<AddProduct products={products} />} />
            <Route path="/products/:name" element={<ProductView />} />
        </Routes>
      </Router>
    </div>
    
  );
}

export default App;
